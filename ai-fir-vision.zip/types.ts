export enum Role {
  CITIZEN = 'CITIZEN',
  POLICE = 'POLICE',
  NONE = 'NONE'
}

export enum FIRStatus {
  DRAFT = 'Draft',
  SUBMITTED = 'Submitted',
  UNDER_INVESTIGATION = 'Under Investigation',
  CLOSED = 'Closed'
}

export interface Evidence {
  id: string;
  type: 'image' | 'document' | 'audio';
  url: string; // Base64 or blob URL
  description: string;
  aiLabel?: string; // Smart label from AI
}

export interface FIR {
  id: string;
  title: string;
  description: string;
  category?: string; // AI Auto-classification
  dateOfIncident: string;
  location: string;
  status: FIRStatus;
  evidence: Evidence[];
  complainantName: string;
  aiAnalysis?: AIAnalysis;
  investigationReport?: InvestigationReport; // New field for deep investigation
  suggestedSections?: string[]; // AI Legal Prediction for Citizen
  createdAt: string;
}

export interface AIAnalysis {
  summary: string;
  severityScore: number; // 1-10
  suggestedSections: string[];
  investigationSteps: string[];
  extractedEntities: string[];
}

export interface SimilarCase {
  firId: string;
  title: string;
  similarityScore: number; // 0-100
  reason: string;
}

export interface SuspectMatch {
  name: string;
  confidence: number; // 0-100
  description: string;
  status: 'Identified' | 'Unknown' | 'Pattern Match';
}

export interface TimelineEvent {
  time: string;
  location: string;
  description: string;
  source: 'CCTV' | 'Witness' | 'Digital Footprint';
}

export interface InvestigationReport {
  similarCases: SimilarCase[];
  suspects: SuspectMatch[];
  timeline: TimelineEvent[];
  contradictions: string[];
  advancedInsights: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  languageCode?: string; // BCP-47 code for TTS
  timestamp: number;
}
